create type aq$_jms_text_message
                                       wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
84 b6
7gjKJHRtSEoKPCevFA7tFooUSd4wg5n0dLhcWlbD9HKXYkqWoTsW9HIuYtHcWa5cj8B0K6W/
m8Ayy+4ljwlppbgy9VKyCabhxmeNMJaajzDj48tp0dsqZhQZxj2uNa/rljbRL4t0w3aLBF2K
7gSRGjjgcHAO9GmKuxoOj3QUviE7iKbIAqiB
/

