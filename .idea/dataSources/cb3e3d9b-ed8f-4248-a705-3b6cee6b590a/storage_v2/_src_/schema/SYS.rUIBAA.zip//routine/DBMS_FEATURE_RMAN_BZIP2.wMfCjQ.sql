create PROCEDURE DBMS_FEATURE_RMAN_BZIP2
     ( feature_boolean  OUT  NUMBER,
       aux_count        OUT  NUMBER,
       feature_info     OUT  CLOB)
AS
    rman_compression  VARCHAR(256);
    algname           VARCHAR(30);
BEGIN

    /* assume that feature is not used. */
    feature_boolean := 0;
    aux_count := 0;
    feature_info := NULL;

    /* Find out compression algorithm we use */
    BEGIN
        SELECT UPPER(value)
          INTO rman_compression
         FROM v$rman_configuration
        WHERE UPPER(name)='COMPRESSION ALGORITHM';
    EXCEPTION
        WHEN OTHERS THEN
           rman_compression := '''DEFAULT''';
    END;

    /* Find the algorithm name, it is always enclosed in single quotes */
    algname := substr(rman_compression, 2,
                      instr(rman_compression, '''', 1, 2) - 2);


    /* Get the number of backup pieces created with compression whose status is
     * 'available', controlfile autobackups are ignored, because we don't
     * want to consider RMAN in use if they just turned on the
     * controlfile autobackup feature.
     * Backups taken with compatible < 11.2 will have a bscal of zero,
     * we will consider them using BZIP2 is the configured algorithm is BZIP2
     * or DEFAULT.
     */
    SELECT count(*)
      INTO aux_count
      FROM (SELECT bp.set_stamp, bp.set_count
              FROM x$kccbs bs
              JOIN v$backup_piece bp
                ON bsbss = bp.set_stamp
               AND bsbsc = bp.set_count
              LEFT OUTER JOIN
                  (SELECT set_stamp, set_count
                     FROM v$backup_datafile
                 GROUP BY set_stamp, set_count
                   HAVING max(file#) = 0) bdf
                ON bdf.set_stamp = bp.set_stamp
               AND bdf.set_count = bp.set_count
             WHERE bp.status = 'A'
               AND bp.compressed = 'YES'
               AND bdf.set_count IS NULL
               AND bdf.set_stamp IS NULL
               AND ((bscal = 0 AND
                     (algname = 'BZIP2' OR algname = 'DEFAULT'))
                OR  (bscal in (144, 208))));

    IF aux_count > 0 THEN
       feature_boolean := 1;
    END IF;
END;
/

