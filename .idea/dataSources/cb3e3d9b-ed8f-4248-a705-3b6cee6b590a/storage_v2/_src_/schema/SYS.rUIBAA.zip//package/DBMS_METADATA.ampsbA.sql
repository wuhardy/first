create PACKAGE dbms_metadata AUTHID CURRENT_USER AS
---------------------------------------------------------------------
-- Overview
-- This pkg implements the mdAPI, a means to retrieve the aggregated
-- definitions of database objects as either XML docs. or their creation DDL,
-- or to submit the XML documents to execute the DDL.
---------------------------------------------------------------------
-- SECURITY
-- This package is owned by SYS with execute access granted to PUBLIC.
-- It runs with invokers rights, i.e., with the security profile of
-- the caller.  It calls DBMS_METADATA_INT to perform privileged
-- functions.
-- The object views defined in catmeta.sql implement the package's security
-- policy via the WHERE clause on the public views which include syntax to
-- control user access to metadata: if the current user is SYS or has
-- SELECT_CATALOG_ROLE, then all objects are visible; otherwise, only
-- objects in the schema of the current user are visible.

--------------------
--  PUBLIC CONSTANTS
--
  SESSION_TRANSFORM     CONSTANT BINARY_INTEGER := -1;
  SESSION_HANDLE        CONSTANT BINARY_INTEGER := -1;

  MAX_PROCOBJ_RETLEN    CONSTANT BINARY_INTEGER := 32767;
  NEWBLOCK_CONTINUE     CONSTANT NUMBER         := 0;
  NEWBLOCK_BEGIN        CONSTANT NUMBER         := 1;
  NEWBLOCK_APPEND       CONSTANT NUMBER         := -2;
--
-- The following types are used in the 'fast convert' interface that returns
-- a single CLOB and collection consisting of a bunch of pointer/length pairs
-- telling the caller where the N DDL statements are in it (as opposed to the
-- interface which returns N CLOBs... less efficient). There is a parallel
-- between these PL/SQL types and the ku$_ddl* / _multi_ddl* types defined
-- above; except these are just pointers and are index by binary_integer
-- collections for performance.
-- (also grantor parse item for procedural grants)
--

--------------------
--  PUBLIC PL/SQL TYPE DEFINITIONS
--
TYPE offset IS RECORD
        (       pos                     PLS_INTEGER,
                len                     PLS_INTEGER,
                grantor                 VARCHAR2(30),
                bind_pattern            VARCHAR2(30),
                alt_connect_type        VARCHAR2(4));

TYPE objddl IS TABLE OF offset INDEX BY BINARY_INTEGER;

TYPE T_VAR_COLL IS TABLE OF VARCHAR2(60) INDEX BY BINARY_INTEGER;

TYPE multiobjects IS TABLE OF objddl INDEX BY BINARY_INTEGER;

-------------
-- EXCEPTIONS
--
  invalid_argval EXCEPTION;
    PRAGMA EXCEPTION_INIT(invalid_argval, -31600);
    invalid_argval_num NUMBER := -31600;
-- "Invalid input value %s for parameter %s in function %s"
-- *Cause:  A NULL or invalid value was supplied for the parameter.
-- *Action: Correct the input value and try the call again.

  invalid_operation EXCEPTION;
    PRAGMA EXCEPTION_INIT(invalid_operation, -31601);
    invalid_operation_num NUMBER := -31601;
-- "Function %s cannot be called now that fetch has begun"
-- *Cause:  The function was called after the first call to FETCH_xxx.
-- *Action: Correct the program.

  inconsistent_args EXCEPTION;
    PRAGMA EXCEPTION_INIT(inconsistent_args, -31602);
    inconsistent_args_num NUMBER := -31602;
-- "parameter %s value \"%s\" in function %s inconsistent with %s"
-- "Value \"%s\" for parameter %s in function %s is inconsistent with %s"
-- *Cause:  The parameter value is inconsistent with another value specified
--          by the program.  It may be not valid for the the object type
--          associated with the OPEN context, or it may be of the wrong
--          datatype: a boolean rather than a text string or vice versa.
-- *Action: Correct the program.

  object_not_found EXCEPTION;
    PRAGMA EXCEPTION_INIT(object_not_found, -31603);
    object_not_found_num NUMBER := -31603;
-- "object \"%s\" of type %s not found in schema \"%s\""
-- *Cause:  The specified object was not found in the database.
-- *Action: Correct the object specification and try the call again.

  invalid_object_param EXCEPTION;
    PRAGMA EXCEPTION_INIT(invalid_object_param, -31604);
    invalid_object_param_num NUMBER := -31604;
-- "invalid %s parameter \"%s\" for object type %s in function %s"
-- *Cause:  The specified parameter value is not valid for this object type.
-- *Action: Correct the parameter and try the call again.

  inconsistent_operation EXCEPTION;
    PRAGMA EXCEPTION_INIT(inconsistent_operation, -31607);
    inconsistent_operation_num NUMBER := -31607;
-- "Function %s is inconsistent with transform."
-- *Cause:  Either (1) FETCH_XML was called when the "DDL" transform
--          was specified, or (2) FETCH_DDL was called when the
--          "DDL" transform was omitted.
-- *Action: Correct the program.

  object_not_found2 EXCEPTION;
    PRAGMA EXCEPTION_INIT(object_not_found2, -31608);
    object_not_found2_num NUMBER := -31608;
-- "specified object of type %s not found"
-- (Used by GET_DEPENDENT_xxx and GET_GRANTED_xxx.)
-- *Cause:  The specified object was not found in the database.
-- *Action: Correct the object specification and try the call again.

  stylesheet_load_error EXCEPTION;
    PRAGMA EXCEPTION_INIT(stylesheet_load_error, -31609);
    stylesheet_load_error_num NUMBER := -31609;
-- "error loading file %s from file system directory \'%s\'"
-- *Cause:  The installation script initmeta.sql failed to load
--          the named file from the file system directory into the database.
-- *Action: Examine the directory and see if the file is present
--          and can be read.

  sql_error EXCEPTION;
    PRAGMA EXCEPTION_INIT(sql_error, -31642);
    sql_error_num NUMBER := -31642;
-- "the following SQL statement failed: %s"
-- *Cause:  An internal error was generated from package DBMS_METADATA.
-- *Action: Call Oracle Support.

  dbmsjava_error EXCEPTION;
    PRAGMA EXCEPTION_INIT(dbmsjava_error, -39128);
    dbmsjava_error_num NUMBER := -39128;
-- "Unexpected DbmsJava error %d from statement %s"
-- *Cause:  The error was returned from a call to a DbmsJava procedure.
-- *Action: Record the accompanying messages and report this as a Data Pump
--          internal error to customer support.

---------------------------
-- PROCEDURES AND FUNCTIONS
--
-- OPEN: Specifies the type of object whose metadata is to be retrieved.
-- PARAMETERS:
--      object_type     - Identifies the type of objects to be retrieved; i.e.,
--              TABLE, INDEX, etc. This determines which view is selected.
--      version         - The version of the objects' metadata to be fetched.
--              To be used in downgrade scenarios: Objects in the DB that are
--              incompatible with an older specified version are not returned.
--              Values can be 'COMPATIBLE' (default), 'LATEST' or a specific
--              version number.
--      model           - The view of the metadata, such as Oracle proprietary,
--              ANSI99, etc.  Currently only 'ORACLE' is supported.
--      network_link    - The name of a database link to the database
--              whose data is to be retrieved.  If NULL (default), metadata
--              is retrieved from the database on which the caller is running.
--
-- RETURNS:
--      A handle to be used in subsequent calls to SET_FILTER, SET_COUNT,
--      ADD_TRANSFORM, GET_QUERY, SET_PARSE_ITEM, FETCH_xxx and CLOSE.
-- EXCEPTIONS:
--      INVALID_ARGVAL  - a NULL or invalid value was supplied for an input
--              parameter.

  FUNCTION open (
                object_type     IN  VARCHAR2,
                version         IN  VARCHAR2 DEFAULT 'COMPATIBLE',
                model           IN  VARCHAR2 DEFAULT 'ORACLE',
                network_link    IN  VARCHAR2 DEFAULT NULL)
        RETURN NUMBER;

-- SET_FILTER: Specifies restrictions on the objects whose metadata
--      is to be retrieved.
--      This function is overloaded: the filter value can be a varchar2,
--      number or boolean.
-- PARAMETERS:
--      handle          - Context handle from previous OPEN call.
--      name            - Name of the filter.
--      value           - Value of the filter.
--      object_type_path- Path name of object types to which
--                        the filter applies.

  PROCEDURE set_filter (
                handle                  IN  NUMBER,
                name                    IN  VARCHAR2,
                value                   IN  VARCHAR2,
                object_type_path        IN  VARCHAR2 DEFAULT NULL);

  PROCEDURE set_filter (
                handle                  IN  NUMBER,
                name                    IN  VARCHAR2,
                value                   IN  BOOLEAN DEFAULT TRUE,
                object_type_path        IN  VARCHAR2 DEFAULT NULL);

  PROCEDURE set_filter (
                handle                  IN  NUMBER,
                name                    IN  VARCHAR2,
                value                   IN  NUMBER,
                object_type_path        IN  VARCHAR2 DEFAULT NULL);


-- SET_COUNT: Specifies the number of objects to be returned in a single
--      FETCH_xxx call.
-- PARAMETERS:
--      handle          - Context handle from previous OPEN call.
--      value           - Number of objects to retrieve.
--      object_type_path- Path name of object types to which
--                        the count applies.

  PROCEDURE set_count (
                handle                  IN  NUMBER,
                value                   IN  NUMBER,
                object_type_path        IN  VARCHAR2 DEFAULT NULL);


-- SET_XMLFORMAT: Specifies formatting attributes for XML output.
-- PARAMETERS:
--      handle          - Context handle from previous OPEN call.
--      name            - Attribute to set. (Only 'PRETTY' is supported.)
--      value           - Value of the attribute.

  PROCEDURE set_xmlformat (
                handle                  IN  NUMBER,
                name                    IN  VARCHAR2,
                value                   IN  BOOLEAN DEFAULT TRUE);

-- GET_QUERY:   Return the text of the query (or queries) that will be
--              used by FETCH_xxx.  This function is provided to aid
--              in debugging.
-- PARAMETERS:  handle  - Context handle from previous OPEN call.
-- RETURNS:     Text of the query.

  FUNCTION get_query (
                handle          IN  NUMBER)
        RETURN VARCHAR2;


-- SET_PARAMETER: Specify parameter values which affect the operation.
-- PARAMETERS:
--      handle          - Context handle from previous OPEN call.
--      name            - Name of the parameter.
--      value           - Value of the parameter.

  PROCEDURE set_parameter (
                handle                  IN  NUMBER,
                name                    IN  VARCHAR2,
                value                   IN  BOOLEAN DEFAULT TRUE);


-- SET_PARSE_ITEM: Enables output parsing and specifies an object attribute
--      to be parsed and returned
-- PARAMETERS:
--      handle  - Context handle from previous OPEN call.
--      name    - Attribute name.
--      object_type- Object type to which the transform applies.

  PROCEDURE set_parse_item (
                handle          IN  NUMBER,
                name            IN  VARCHAR2,
                object_type     IN  VARCHAR2 DEFAULT NULL);


-- ADD_TRANSFORM : Specify a transform to be applied to the XML representation
--              of objects processed by FETCH_xxx, CONVERT or PUT.
-- PARAMETERS:  handle  - Context handle from previous OPEN or OPENW call.
--              name    - The name of the transform: Can be 'DDL' to generate
--                        creation DDL or a URI pointing to a stylesheet,
--                        either external or internal to the DB (the latter
--                        being an Xpath spec. starting with '/oradb').
--              encoding- If name is a URI, this specifies the encoding of the
--                        target stylesheet. If left NULL, then if uri starts
--                        with  '/oradb', then the database char. set is used;
--                        otherwise, 'UTF-8'. Use 'US-ASCII' for better perf.
--                        if you can. May be any valid NLS char. set name.
--                        Ignored if name is an internal transform name (like
--                        DDL), not a URI.
--              object_type- Object type to which the transform applies.
--
-- NOTE: If name is an intra-DB uri (ie, /oradb) that points to an NCLOB
--       column or a CLOB with an encoding different from the database charset,
--       you must explicitly specify the encoding.
-- RETURNS:     An opaque handle to the transform to be used in subsequent
--              calls to SET_TRANSFORM_PARAM.

  FUNCTION add_transform (
                handle          IN NUMBER,
                name            IN VARCHAR2,
                encoding        IN VARCHAR2 DEFAULT NULL,
                object_type     IN VARCHAR2 DEFAULT NULL)
        RETURN NUMBER;


-- SET_TRANSFORM_PARAM: Specifies a value for a parameter to the XSL-T
--      stylesheet identified by handle.
--      This procedure is overloaded: the parameter value can be a varchar2,
--      a number or a boolean.
-- PARAMETERS:
--      transform_handle - Handle from previous ADD_TRANSFORM call.
--      name             - Name of the parameter.
--      value            - Value for the parameter.
--      object_type      - Object type to which the transform param applies.

  PROCEDURE set_transform_param (
                transform_handle        IN  NUMBER,
                name                    IN  VARCHAR2,
                value                   IN  VARCHAR2,
                object_type             IN  VARCHAR2 DEFAULT NULL);

  PROCEDURE set_transform_param (
                transform_handle        IN  NUMBER,
                name                    IN  VARCHAR2,
                value                   IN  BOOLEAN DEFAULT TRUE,
                object_type             IN  VARCHAR2 DEFAULT NULL);

  PROCEDURE set_transform_param (
                transform_handle        IN  NUMBER,
                name                    IN  VARCHAR2,
                value                   IN  NUMBER,
                object_type             IN  VARCHAR2 DEFAULT NULL);

-- SET_REMAP_PARAM: Specifies a value for a parameter to the XSL-T
--      stylesheet identified by handle.
-- PARAMETERS:
--      transform_handle - Handle from previous ADD_TRANSFORM call.
--      name             - Name of the parameter.
--      old_value        - Old value for the remapping
--      new_value        - New value for the remapping
--      object_type      - Object type to which the transform param applies.

  PROCEDURE set_remap_param (
                transform_handle        IN  NUMBER,
                name                    IN  VARCHAR2,
                old_value               IN  VARCHAR2,
                new_value               IN  VARCHAR2,
                object_type             IN  VARCHAR2 DEFAULT NULL);

-- FETCH_XML:   Return metadata for objects as XML documents. This version
--              can return multiple objects per call (when the SET_COUNT
--              'value' parameter > 1).
-- PARAMETERS:  handle  - Context handle from previous OPEN call.
-- RETURNS:     XML metadata for the objects as an XMLType, or NULL if all
--              objects have been fetched.
-- EXCEPTIONS:  Throws an exception if DDL transform has been added

  FUNCTION fetch_xml (handle    IN NUMBER)
        RETURN sys.XMLType;


-- FETCH_DDL:   Return metadata as DDL.
--              More than one DDL statement may be returned.
-- RETURNS:     Metadata for the objects as one or more DDL statements
-- PARAMETERS:  handle  - Context handle from previous OPEN call.
-- EXCEPTIONS:  Throws an exception if DDL transform was not added.

  FUNCTION fetch_ddl (
                handle  IN NUMBER)
        RETURN sys.ku$_ddls;


--************* TEMPORARY ************************
-- FETCH_DDL_TEXT: Return DDL metadata as VARCHAR2.
--              NOTE: This is a temporary API for logical standby.
--              It is needed because LOBs and objects cannot
--              currently (8.2) be returned over dblinks.
-- RETURNS:     Metadata for the object as one DDL statement
-- PARAMETERS:  handle  - Context handle from previous OPEN call.
--              partial - set to 1 if the statement was too long
--                      to fit in the VARCHAR2; the next call will
--                      return the next piece of the metadata.
-- EXCEPTIONS:  Throws an exception if DDL transform was not added.

  FUNCTION fetch_ddl_text (
                handle  IN  NUMBER,
                partial OUT NUMBER)
        RETURN VARCHAR2;
--************* TEMPORARY ************************


-- FETCH_CLOB:  Return metadata for object (transformed or not) as a CLOB.
-- PARAMETERS:  handle  - Context handle from previous OPEN call.
--              cache_lob - TRUE = read LOB into buffer cache
--              lob_duration - either DBMS_LOB.SESSION (default)
--                or DBMS_LOB.CALL, the duration for the termporary lob
-- RETURNS:     XML metadata for the objects as a CLOB, or NULL if all
--              objects have been fetched.

  FUNCTION fetch_clob (handle       IN NUMBER,
                       cache_lob    IN BOOLEAN DEFAULT TRUE,
                       lob_duration IN PLS_INTEGER DEFAULT DBMS_LOB.SESSION)
        RETURN CLOB;


-- PROCEDURE FETCH_CLOB: Same as above but with IN/OUT NOCOPY CLOB. CLOB
--              must be pre-created prior to call.
-- PARAMETERS:	handle- (IN) Context handle from previous OPENC call.
--              xmldoc - (IN OUT) previously allocated CLOB to hold the
--                       returned diff document.

  PROCEDURE fetch_clob (
                handle  IN NUMBER,
                xmldoc  IN OUT NOCOPY CLOB);

-- NETWORK_OPEN: Do OPEN over network; negotiate protocol version
--               This function is called by the local server and
--               runs in the remote server.
-- PARAMETERS:
--      object_type     - See 'OPEN'
--      version         - See 'OPEN'
--      model           - See 'OPEN'
--      client_version  - The highest protocol version understood by
--                        the caller.
--      protocol_version- The protocol version to be used in this session.
--                        NETWORK_OPEN picks the highest protocol version
--                        understood by both itself and the caller.
--
-- RETURNS:
--      A handle to be used in subsequent calls to SET_FILTER, SET_COUNT,
--      ADD_TRANSFORM, GET_QUERY, SET_PARSE_ITEM, FETCH_xxx and CLOSE.
-- EXCEPTIONS:
--      INVALID_ARGVAL  - a NULL or invalid value was supplied for an input
--              parameter.

  FUNCTION network_open (
                object_type      IN  VARCHAR2,
                version          IN  VARCHAR2 DEFAULT 'COMPATIBLE',
                model            IN  VARCHAR2 DEFAULT 'ORACLE',
                client_version   IN  NUMBER,
                protocol_version OUT NUMBER)
        RETURN NUMBER;

-- NETWORK_CALLOUTS: Execute callouts on remote instance
--    (These can't execute in the context of a remote function.)
-- PARAMETERS:  handle       - Context handle from previous OPEN call.

  PROCEDURE network_callouts (
                handle          IN  NUMBER );

-- NETWORK_FETCH_CLOB: Return metadata as VARCHAR2.
-- RETURNS:     Metadata for the object
-- PARAMETERS:  handle       - Context handle from previous OPEN call.
--              do_xsl_parse - 1 = do parse the XSL way
--              partial      - set to 1 if the statement was too long
--                      to fit in the VARCHAR2; the next call will
--                      return the next piece of the metadata.
--              parse_delim  - the parse delimiter
--              do_callout   - set to 1 if the next action is a callout
--                             0 otherwise
--              have_errors  - set to 1 if procedural object/action code
--                             raised an exception that should be fetched
--                             0 otherwise

  FUNCTION network_fetch_clob (
                handle          IN  NUMBER,
                do_xsl_parse    IN  NUMBER,
                partial         OUT NUMBER,
                parse_delim     OUT VARCHAR2,
                do_callout      OUT NUMBER,
                have_errors     OUT NUMBER)
        RETURN VARCHAR2;

-- NETWORK_FETCH_ERRORS: Serializes a ku$_vcnt into a VARCHAR2 for
--              network operations. (modeled on NETWORK_FETCH_PARSE, below)
-- RETURNS:     VARCHAR2: A delimited series of error string
-- PARAMETERS:  handle   - Context handle from previous OPEN call.
--              cnt      - Number of errors returned this iteration
--              partial  - set to 1 if there's more to come
--              seqno    - Seq. number for current member of heterogeneous obj.
--              path     - Path for current member of heterogeneous obj.
--
-- IMPLICIT INPUTS: pkg-scoped parse_pattern established by network_fetch_clob

  FUNCTION network_fetch_errors (
                handle          IN  NUMBER,
                cnt             OUT NUMBER,
                partial         OUT NUMBER,
                seqno           OUT NUMBER,
                path            OUT VARCHAR2)
        RETURN VARCHAR2;

-- NETWORK_FETCH_PARSE: Serializes a ku$_parsed_items into a VARCHAR2 for
--              network operations.
-- RETURNS:     varchar2 is a delimited series of ku$_parsed_item attributes
-- PARAMETERS:  handle   - Context handle from previous OPEN call.
--              cnt      - Number of parse items returned this iteration
--              partial  - set to 1 if there's more to come
--              seqno    - Seq. number for current member of heterogeneous obj.
--              path     - Path for current member of heterogeneous obj.

  FUNCTION network_fetch_parse (
                handle          IN  NUMBER,
                cnt             OUT NUMBER,
                partial         OUT NUMBER,
                seqno           OUT NUMBER,
                path            OUT VARCHAR2)
        RETURN VARCHAR2;

---------------------------------------------------------------------
-- FETCH_XML_CLOB:      Procedure variant with IN/OUT NOCOPY CLOB.
--              Also returns nested table of parsed items, object type path.
-- PARAMETERS:  handle  - Context handle from previous OPEN call.
--              doc - XML metadata for the objects or NULL if all
--                objects have been fetched.
--              parsed_items - Table of parsed items.
--              object_type_path - for heterogeneous object types the full
--                path name of the object type for the object(s) returned;
--                NULL if handle is for a homogeneous object type
--              seqno - for heterogeneous object types the sequence
--                number of the object type in the heterogeneous collection;
--                NULL if handle is for a homogeneous object type
--              procobj_errors - nested table of varchar2 - each entry
--                contains an exception raised by procedural action code.
--                NULL if no exceptions raised
-- EXCEPTIONS:  Throws an exception if DDL transform has been added.

  PROCEDURE fetch_xml_clob (
                handle                  IN  NUMBER,
                doc                     IN OUT NOCOPY CLOB,
                parsed_items            IN OUT NOCOPY sys.ku$_parsed_items,
                object_type_path        OUT VARCHAR2);

  PROCEDURE fetch_xml_clob (
                handle                  IN  NUMBER,
                doc                     IN OUT NOCOPY CLOB,
                parsed_items            IN OUT NOCOPY sys.ku$_parsed_items,
                object_type_path        OUT VARCHAR2,
                seqno                   OUT NUMBER,
                procobj_errors          OUT sys.ku$_vcnt);

-- CLOSE:       Cleanup all context associated with handle.
-- PARAMETERS:  handle  - Context handle from previous OPEN call.

  PROCEDURE CLOSE (handle IN NUMBER);


-- GET_XML:     Return the metadata for a single object as XML.
--      This interface is meant for casual browsing (e.g., from SQLPlus)
--      vs. the programmatic OPEN / FETCH / CLOSE interfaces above.
-- PARAMETERS:
--      object_type     - The type of object to be retrieved.
--      name            - Name of the object.
--      schema          - Schema containing the object.  Defaults to
--                        the caller's schema.
--      version         - The version of the objects' metadata.
--      model           - The object model for the metadata.
--      transform       - XSL-T transform to be applied.
-- RETURNS:     Metadata for the object as an NCLOB.

  FUNCTION get_xml (
                object_type     IN  VARCHAR2,
                name            IN  VARCHAR2,
                schema          IN  VARCHAR2 DEFAULT NULL,
                version         IN  VARCHAR2 DEFAULT 'COMPATIBLE',
                model           IN  VARCHAR2 DEFAULT 'ORACLE',
                transform       IN  VARCHAR2 DEFAULT NULL)
        RETURN CLOB;


-- GET_SXML:     Return the metadata for a single object as SXML.
--      This interface is meant for casual browsing (e.g., from SQLPlus)
--      vs. the programmatic OPEN / FETCH / CLOSE interfaces above.
-- PARAMETERS:
--      object_type     - The type of object to be retrieved.
--      name            - Name of the object.
--      schema          - Schema containing the object.  Defaults to
--                        the caller's schema.
--      version         - The version of the objects' metadata.
--      model           - The object model for the metadata.
--      transform       - XSL-T transform to be applied.
-- RETURNS:     Metadata for the object transformed to SXML as a CLOB.

  FUNCTION get_sxml (
                object_type     IN  VARCHAR2,
                name            IN  VARCHAR2,
                schema          IN  VARCHAR2 DEFAULT NULL,
                version         IN  VARCHAR2 DEFAULT 'COMPATIBLE',
                model           IN  VARCHAR2 DEFAULT 'ORACLE',
                transform       IN  VARCHAR2 DEFAULT 'SXML')
        RETURN CLOB;

-- GET_SXML_DDL:     Return the metadata for a single object, convert it
--      to SXML, then convert the SXML to DDL.
--      Used for testing the SXML and SXMLDDL transforms.
-- PARAMETERS:
--      object_type     - The type of object to be retrieved.
--      name            - Name of the object.
--      schema          - Schema containing the object.  Defaults to
--                        the caller's schema.
--      version         - The version of the objects' metadata.
--      model           - The object model for the metadata.
--      transform       - XSL-T transform to be applied.
-- RETURNS:     Metadata for the object transformed to SXML, then DDL,
--               as a CLOB.

  FUNCTION get_sxml_ddl (
                object_type     IN  VARCHAR2,
                name            IN  VARCHAR2,
                schema          IN  VARCHAR2 DEFAULT NULL,
                version         IN  VARCHAR2 DEFAULT 'COMPATIBLE',
                model           IN  VARCHAR2 DEFAULT 'ORACLE',
                transform       IN  VARCHAR2 DEFAULT 'SXMLDDL')
        RETURN CLOB;

-- GET_DDL:     Return the metadata for a single object as DDL.
--      This interface is meant for casual browsing (e.g., from SQLPlus)
--      vs. the programmatic OPEN / FETCH / CLOSE interfaces above.
-- PARAMETERS:
--      object_type     - The type of object to be retrieved.
--      name            - Name of the object.
--      schema          - Schema containing the object.  Defaults to
--                        the caller's schema.
--      version         - The version of the objects' metadata.
--      model           - The object model for the metadata.
--      transform       - XSL-T transform to be applied.
-- RETURNS:     Metadata for the object transformed to DDL as a CLOB.

  FUNCTION get_ddl (
                object_type     IN  VARCHAR2,
                name            IN  VARCHAR2,
                schema          IN  VARCHAR2 DEFAULT NULL,
                version         IN  VARCHAR2 DEFAULT 'COMPATIBLE',
                model           IN  VARCHAR2 DEFAULT 'ORACLE',
                transform       IN  VARCHAR2 DEFAULT 'DDL')
        RETURN CLOB;

-- GET_DEPENDENT_XML:   Return the metadata for objects dependent on a
--      base object as XML.
--      This interface is meant for casual browsing (e.g., from SQLPlus)
--      vs. the programmatic OPEN / FETCH / CLOSE interfaces above.
-- PARAMETERS:
--      object_type     - The type of object to be retrieved.
--      base_object_name- Name of the base object.
--      base_object_schema- Schema containing the base object.  Defaults to
--                        the caller's schema.
--      version         - The version of the objects' metadata.
--      model           - The object model for the metadata.
--      transform       - XSL-T transform to be applied.
--      object_count    - maximum number of objects to return
-- RETURNS:     Metadata for the object as a CLOB.

  FUNCTION get_dependent_xml (
                object_type             IN  VARCHAR2,
                base_object_name        IN  VARCHAR2,
                base_object_schema      IN  VARCHAR2 DEFAULT NULL,
                version                 IN  VARCHAR2 DEFAULT 'COMPATIBLE',
                model                   IN  VARCHAR2 DEFAULT 'ORACLE',
                transform               IN  VARCHAR2 DEFAULT NULL,
                object_count            IN  NUMBER   DEFAULT 10000)
        RETURN CLOB;

-- GET_DEPENDENT_SXML:   Return the metadata for objects dependent on a
--      base object as XML.
--      This interface is meant for casual browsing (e.g., from SQLPlus)
--      vs. the programmatic OPEN / FETCH / CLOSE interfaces above.
-- PARAMETERS:
--      object_type     - The type of object to be retrieved.
--      base_object_name- Name of the base object.
--      base_object_schema- Schema containing the base object.  Defaults to
--                        the caller's schema.
--      version         - The version of the objects' metadata.
--      model           - The object model for the metadata.
--      transform       - XSL-T transform to be applied.
--      object_count    - maximum number of objects to return
-- RETURNS:     Metadata for the object as a CLOB.

  FUNCTION get_dependent_sxml (
                object_type             IN  VARCHAR2,
                base_object_name        IN  VARCHAR2,
                base_object_schema      IN  VARCHAR2 DEFAULT NULL,
                version                 IN  VARCHAR2 DEFAULT 'COMPATIBLE',
                model                   IN  VARCHAR2 DEFAULT 'ORACLE',
                transform               IN  VARCHAR2 DEFAULT 'SXML',
                object_count            IN  NUMBER   DEFAULT 10000)
        RETURN CLOB;

-- GET_DEPENDENT_DDL:   Return the metadata for objects dependent on a
--      base object as DDL.
--      This interface is meant for casual browsing (e.g., from SQLPlus)
--      vs. the programmatic OPEN / FETCH / CLOSE interfaces above.
-- PARAMETERS:
--      object_type     - The type of object to be retrieved.
--      base_object_name- Name of the base object.
--      base_object_schema- Schema containing the base object.  Defaults to
--                        the caller's schema.
--      version         - The version of the objects' metadata.
--      model           - The object model for the metadata.
--      transform       - XSL-T transform to be applied.
--      object_count    - maximum number of objects to return
-- RETURNS:     Metadata for the object as a CLOB.

  FUNCTION get_dependent_ddl (
                object_type             IN  VARCHAR2,
                base_object_name        IN  VARCHAR2,
                base_object_schema      IN  VARCHAR2 DEFAULT NULL,
                version                 IN  VARCHAR2 DEFAULT 'COMPATIBLE',
                model                   IN  VARCHAR2 DEFAULT 'ORACLE',
                transform               IN  VARCHAR2 DEFAULT 'DDL',
                object_count            IN  NUMBER   DEFAULT 10000)
        RETURN CLOB;

-- GET_GRANTED_XML:     Return the metadata for objects granted to a
--      grantee as XML.
--      This interface is meant for casual browsing (e.g., from SQLPlus)
--      vs. the programmatic OPEN / FETCH / CLOSE interfaces above.
-- PARAMETERS:
--      object_type     - The type of object to be retrieved.
--      grantee         - Name of the grantee.
--      version         - The version of the objects' metadata.
--      model           - The object model for the metadata.
--      transform       - XSL-T transform to be applied.
--      object_count    - maximum number of objects to return
-- RETURNS:     Metadata for the object as a CLOB.

  FUNCTION get_granted_xml (
                object_type     IN  VARCHAR2,
                grantee         IN  VARCHAR2 DEFAULT NULL,
                version         IN  VARCHAR2 DEFAULT 'COMPATIBLE',
                model           IN  VARCHAR2 DEFAULT 'ORACLE',
                transform       IN  VARCHAR2 DEFAULT NULL,
                object_count    IN  NUMBER   DEFAULT 10000)
        RETURN CLOB;

-- GET_GRANTED_DDL:     Return the metadata for objects granted to a
--      grantee as DDL.
--      This interface is meant for casual browsing (e.g., from SQLPlus)
--      vs. the programmatic OPEN / FETCH / CLOSE interfaces above.
-- PARAMETERS:
--      object_type     - The type of object to be retrieved.
--      grantee         - Name of the grantee.
--      version         - The version of the objects' metadata.
--      model           - The object model for the metadata.
--      transform       - XSL-T transform to be applied.
--      object_count    - maximum number of objects to return
-- RETURNS:     Metadata for the object as a CLOB.

  FUNCTION get_granted_ddl (
                object_type     IN  VARCHAR2,
                grantee         IN  VARCHAR2 DEFAULT NULL,
                version         IN  VARCHAR2 DEFAULT 'COMPATIBLE',
                model           IN  VARCHAR2 DEFAULT 'ORACLE',
                transform       IN  VARCHAR2 DEFAULT 'DDL',
                object_count    IN  NUMBER   DEFAULT 10000)
        RETURN CLOB;

-- GET_DPSTRM_MD: Retrieve stream (i.e., table) metadata
--      for DataPump data layer.
-- PARAMETERS:
--      schema - the table's schema
--      name   - the table's name
--      mdversion - the version of metadata to be extracted, one of
--                      - COMPATIBLE (default) - version of metadata
--                              corresponds to database compatibility level
--                      - LATEST - corresponds to database version
--                      - a specific database version
--      dpapiversion - the direct path API version (this value is stored
--                      in the returned XML document)
--      doc    - An XML document containing the stream metadata
--               for the table/partition.
--      network_link    - The name of a database link to the database
--              whose data is to be retrieved.  If NULL (default), metadata
--              is retrieved from the database on which the caller is running.
--      force_lob_be - if TRUE, clear bit 0x0200 of
--              COL_LIST/COL_LIST_ITEM/LOB_PROPERTY, i.e., force the metadata
--              to make the lob appear big endian.
--      force_no_encrypt - if TRUE, clear encryption bits in col$ properties:
--              0x04000000 =  67108864 = Column is encrypted
--              0x20000000 = 536870912 = Column is encrypted without salt
--              This is necessary when users do not specify an
--              encryption_password and the data is written to the dumpfile
--              in clear text although the col properity retains the
--              encrypt property.
  PROCEDURE get_dpstrm_md (
                schema          IN VARCHAR2,
                name            IN VARCHAR2,
                mdversion       IN VARCHAR2 DEFAULT 'COMPATIBLE',
                dpapiversion    IN NUMBER DEFAULT 3,
                doc             IN OUT NOCOPY CLOB,
                network_link    IN VARCHAR2 DEFAULT NULL,
                force_lob_be    IN BOOLEAN DEFAULT FALSE,
                force_no_encrypt IN BOOLEAN DEFAULT FALSE);

-- SET_DEBUG: Set the internal debug switch.
-- PARAMETERS:
--      on_off       - new switch state.
--	arg2	     - unused argument to force the overloading of
--                     this procedure (i.e., overloaded version of this
--                     routine will match the common datapump interface.


  PROCEDURE set_debug(
                on_off          IN BOOLEAN,
                arg2            IN BOOLEAN DEFAULT TRUE);

-- SET_DEBUG: Enable Metadata tracing.
-- PARAMETERS:
--	debug_flags  - trace flag bitvector (see prvtkupc.sql for bit defs).
 PROCEDURE set_debug(
		debug_flags	IN BINARY_INTEGER);

-- NET_SET_DEBUG: Set the internal debug switch on a remote node.
--   This function is called by the local server and runs on the
--   remote server.
-- PARAMETERS:
--      on_off          - new switch state: 0 = OFF, non-0 = ON.

  PROCEDURE net_set_debug(
                on_off          IN NUMBER);

-- FREE_CONTEXT_ENTRY: free the entry in context_list corresponding to 'ind'
--              Should only be called by pkg. dbms_metadata_int.
-- PARAMETERS:
--      ind             - index of entry to free

  PROCEDURE free_context_entry (
                ind             IN  NUMBER );


-- FETCH_OBJNUMS: Table function to return object numbers
-- PARAMETERS:
--      handle          - handle returned from open

  FUNCTION FETCH_OBJNUMS (
                handle                  IN  NUMBER )
        RETURN sys.ku$_ObjNumSet pipelined;

  FUNCTION FETCH_OBJNUMS
        RETURN sys.ku$_ObjNumSet pipelined;

-- FETCH_OBJNUMS_NAMES: Table function to return object numbers and names
-- IMPLICIT PARAMETER: <current handle>

  FUNCTION FETCH_OBJNUMS_NAMES
        RETURN sys.ku$_ObjNumNamSet pipelined;

-- FETCH_SORTED_OBJNUMS: Table function to return nested table of
--       obj#-order pairs
-- PARAMETERS:
--      handle          - handle returned from open

  FUNCTION FETCH_SORTED_OBJNUMS (
                handle                  IN  NUMBER )
        RETURN sys.ku$_ObjNumPairList;


-- GET_DOMIDX_METADATA: Get PLSQL code from the ODCIIndexGetMetadata
-- method of a domain index's implementation type.
-- PARAMETERS:
--      index_name      - name of the domain index
--      index_schema    - schema of the domain index
--      type_name       - name of the index's implementation type
--      type_schema     - schema of the index's implementation type
--      itinter_version - Interface version of the index's implementation type
--      flags           - flags
-- RETURNS:     Collection of VARCHAR2 containing a PL/SQL block
--      that creates the index metadata.

  FUNCTION get_domidx_metadata(
                index_name      IN  VARCHAR2,
                index_schema    IN  VARCHAR2,
                type_name       IN  VARCHAR2,
                type_schema     IN  VARCHAR2,
                itinter_version IN  NUMBER,
                flags           IN  NUMBER)
        RETURN sys.ku$_procobj_lines;

-- OKTOEXP_2NDARY_TABLE: Should a secondary object of a domain index
-- be exported?
-- PARAMETERS:
--      tab_obj_num     - object number of the secondary table
-- RETURNS:     TRUE = yes, export it

  FUNCTION oktoexp_2ndary_table (
                tab_obj_num     IN  NUMBER)
        RETURN PLS_INTEGER;

-- PATCH_TYPEID: For transportable import, modify a type's typeid.
-- PARAMETERS:
--      schema   - the type's schema
--      name     - the type's name
--      typeid   - the type's typeid
--      hashcode - the type's hashcode

  PROCEDURE patch_typeid (
                schema          IN VARCHAR2,
                name            IN VARCHAR2,
                typeid          IN VARCHAR2,
                hashcode        IN VARCHAR2);

-- CHECK_TYPE: For transportable import, check a type's defintion and
--             typeid for a match against the one from the export source.
-- PARAMS:
--      schema     - schema of type
--      type_name  - type name
--      version    - internal stored verson of type
--      hashcode   - hashcode of the type defn
--      typeid     - subtype typeid ('' if no subtypes)
-- RETURNS: Nothing, returns if the hashcode and version match. Raises an
--          nnn exception if the type does not exist in the db or if the
--          type exists but the hash code and/or the version number does
--          not match.
--
PROCEDURE check_type    (schema     IN VARCHAR2,
                         type_name  IN VARCHAR2,
                         version    IN VARCHAR2,
                         hashcode   IN VARCHAR2,
		         typeid     IN VARCHAR2);


-- GET_HASHCODE: Upgrade from 817 corrupts the hashcode in type$,
--   so we have to get it by calling kotgHashCode.
--   This function calls utl_cxml.getHashCode which calls into kux.c.
-- PARAMS:
--      schema          - type schema
--      typename        - type name
-- RETURNS:
--      hashcode        - returned hashcode

 FUNCTION get_hashcode (schema   IN  VARCHAR2,
                       typename IN  VARCHAR2) RETURN RAW;


-- GET_SYSPRIVS
--      Get the export string from call grant_sysprivs_exp
--      and audit_sysprivs_exp function of a package in exppkgobj$
-- PARAMETERS:
--      package     -- package name
--      pkg_schema  -- schema of package
--      function    -- function name(audit_sysprivs_exp or grant_sysprivs_exp)
-- RETURNS:     system_info export string

  FUNCTION get_sysprivs(
                package         IN  VARCHAR2,
                pkg_schema      IN  VARCHAR2,
                function        IN  VARCHAR2)
        RETURN sys.ku$_procobj_lines;

-----------------------------------------------------------------------
-- GET_PROCOBJ
--   Get the export string from call create_exp or audit_exp or grant_exp
--   function of package in exppkobj$
-- PARAMETERS:
--      package     -- package name
--      pkg_schema  -- schema of package
--      function    -- function name (create_exp or audit_exp or grant_exp)
--      objid       -- object number
--      isdba       -- 1: is dba
-- RETURNS:     create/audit/grant export string

  FUNCTION get_procobj(
                package         IN  VARCHAR2,
                pkg_schema      IN  VARCHAR2,
                function        IN  VARCHAR2,
                objid           IN  NUMBER,
                isdba           IN  PLS_INTEGER
                )
        RETURN sys.ku$_procobj_lines;
-----------------------------------------------------------------------
-- GET_PROCOBJ_GRANT
--   Get the export string from call grant_exp function of package in exppkobj$
-- PARAMETERS:
--      package     -- package name
--      pkg_schema  -- schema of package
--      function    -- function name (grant_exp)
--      objid       -- object number
--      isdba       -- 1: is dba
-- RETURNS:     create/audit/grant export string

  FUNCTION get_procobj_grant(
                package         IN  VARCHAR2,
                pkg_schema      IN  VARCHAR2,
                function        IN  VARCHAR2,
                objid           IN   NUMBER,
                isdba           IN   PLS_INTEGER
                )
        RETURN sys.ku$_procobj_lines;

-----------------------------------------------------------------------
-- GET_ACTION_INSTANCE
--  Get the export string from call instance_info_exp and
--  instance_extented_info_exp function of package in exppkgact$
-- PARAMETERS:
--      package     -- package name
--      pkg_schema  -- schema of package
--      function    -- function name (instance_info_exp
--                      or instance_extended_info_exp)
--      name        -- instance name
--      schema      -- instance schema
--      namespace   --
--      objtype     --
--      prepost     -- 0: pre-action, 1:post_action
--      isdba       -- 1: is dba
-- RETURNS:
--      instance info  export_string

  FUNCTION get_action_instance(
         package        IN  VARCHAR2,
         pkg_schema     IN  VARCHAR2,
         function       IN  VARCHAR2,
         name           IN  VARCHAR2,
         schema         IN  VARCHAR2,
         namespace      IN  number,
         objtype        IN  number,
         prepost        IN  number,
         isdba          IN  number)
        RETURN sys.ku$_procobj_lines;

-----------------------------------------------------------------------
-- GET_ACTION_SYS
--    Get the export string from call system_info_exp function of package
--    in exppkgact$
-- PARAMETERS:
--      package    -- package name
--      pkg_schema -- schema of package
--      function   -- function name (system_info_exp)
--      prepost    -- 0 :pre-action, 1: post-action
-- RETURNS:
--      system info  export_string

  FUNCTION get_action_sys(
                package         IN  VARCHAR2,
                pkg_schema      IN  VARCHAR2,
                function        IN  VARCHAR2,
                prepost         IN NUMBER)
        RETURN sys.ku$_procobj_lines;

-----------------------------------------------------------------------
-- GET_ACTION_SCHEMA
--      Get the export string from call schema_info_exp
--      function of package in exppkgact$
-- PARAMETERS:
--      package    -- package name
--      pkg_schema -- schema of package
--      function   -- function name (schema_info_exp)
--      schema     -- each user
--      prepost    -- 0 :pre-action, 1: post-action
--      isdba      -- 1: is dba
-- RETURNS:
--      schema info  export_string

  FUNCTION get_action_schema(
                package         IN  VARCHAR2,
                pkg_schema      IN  VARCHAR2,
                function        IN  VARCHAR2,
                schema          IN  VARCHAR2,
                prepost         IN NUMBER,
                isdba           IN NUMBER)
        RETURN sys.ku$_procobj_lines;

-----------------------------------------------------------------------
-- GET_PLUGTS_BLK : Get PLSQL code from dbms_plugts.selectBlock and getLine.
--      This generates the pre-import and post-import anonymous blocks
--      for transportable.
-- PARAMETERS:
--      blockID         - 0 = pre-import; non-0 = post-import

  FUNCTION get_plugts_blk (
                blockID         IN NUMBER )
        RETURN sys.ku$_procobj_lines;

-- GET_JAVA_METADATA: Return java class, source, resource info
-- PARAMETERS:
--      java_name       - java class or resource or source name
--      schema_name     - schema name
--      type_num        - object type
-- RETURNS: nested table of java info

 FUNCTION get_java_metadata(
                java_name       IN  VARCHAR2,
                java_schema     IN  VARCHAR2,
                type_num        IN  NUMBER)
        RETURN sys.ku$_java_t;


-- GET_PREPOST_TABLE_ACT
--    Get the export string for pre-table action
--            from call sys.dbms_export_extension.pre_table
--    Get the export string for post-table action
--            from call sys.dbms_export_extension.post_tables
-- PARAMETERS:
--      prepost   -- 1 is pre-table action, 2 is post-table action
--      schema    -- schema name
--      tname     -- table name
-- RETURNS:
--      table pre/post table action string

  FUNCTION get_prepost_table_act(
                prepost IN  NUMBER,
                schema  IN  VARCHAR2,
                tname   IN  VARCHAR2)
        RETURN sys.ku$_taction_list_t;

-- GET_CANONICAL_VSN: convert the user's VERSION param to a string
--       in the format vv.vv.vv.vv.vv, e.g., '08.01.03.00.00'
-- PARAMETERS:
--      version         - The version from DBMS_METADATA.OPEN.
--              Values can be 'COMPATIBLE' (default), 'LATEST' or a specific
--              version number.

  FUNCTION get_canonical_vsn(version IN VARCHAR2)
        RETURN VARCHAR2;

---------------------------------------------------------------------
-- CONVERT_TO_CANONICAL: Convert string to canonical form
--       vv.vv.vv.vv.vv, e.g., '08.01.03.00.00'
-- PARAMETERS:
--      version         - version string (e.g., 10.2.0.2)

  FUNCTION convert_to_canonical(version IN VARCHAR2)
        RETURN VARCHAR2;

---------------------------------------------------------------------
-- GET_INDEX_INTCOL - Get intcol# in table of column on which index is
--                    defined (need special handling for xmltype cols)
-- PARAMETERS:
--      obj_num         - base table object #
--      intcol_num      - intcol# from icol$
--
-- This is a wrapper function around dbms_metadata_util.get_index_intcol.


  FUNCTION get_index_intcol(obj_num IN NUMBER,
                            intcol_num in NUMBER)
        RETURN NUMBER;

---------------------------------------------------------------------
-- OPENW: Specifies the type of object whose metadata is to be submitted.
-- PARAMETERS:
--      object_type     - Identifies the type of objects to be submitted; e.g.,
--                        TABLE, INDEX, etc. May not be a heterogeneous
--                        object type.
--      version         - The version of the objects' DDL to be created.
--              Values can be 'COMPATIBLE' (default), 'LATEST' or a specific
--              version number.
--      model           - The view of the metadata, such as Oracle proprietary,
--                        ANSI99, etc.  Currently only 'ORACLE' is supported.
--
-- RETURNS:
--      A handle to be used in subsequent calls to ADD_TRANSFORM, CONVERT,
--      PUT and CLOSE.
-- EXCEPTIONS:
--      INVALID_ARGVAL  - a NULL or invalid value was supplied for an input
--              parameter.

  FUNCTION openw (
                object_type     IN  VARCHAR2,
                version         IN  VARCHAR2 DEFAULT 'COMPATIBLE',
                model           IN  VARCHAR2 DEFAULT 'ORACLE')
        RETURN NUMBER;


-- CONVERT:     Convert an input XML document into creation DDL.
--              More than one DDL statement may be returned.
-- RETURNS:     Metadata for the objects as one or more DDL statements
-- PARAMETERS:  handle   - Context handle from previous OPENW call.
--              document - XML document containing object metadata of
--                         the type of the OPENW handle.
-- EXCEPTIONS:  Throws an exception if DDL transform was not added.

  FUNCTION convert (
                handle          IN NUMBER,
                document        IN sys.XMLType)
        RETURN sys.ku$_multi_ddls;

  FUNCTION convert (
                handle          IN NUMBER,
                document        IN CLOB)
        RETURN sys.ku$_multi_ddls;


-- CONVERT:     This is an alternate, higher-performing but less flexible form
--              of CONVERT that returns only a single (but multi-object) CLOB
--              with a collection providing offsets into this CLOB to locate
--              each individual DDL. Parse items per DDL are NOT returned with
--              this version.
-- RETURNS:     CLOB containing multiple DDL statements.
-- PARAMETERS:  handle   - Context handle from previous OPENW call.
--              document - CLOB containing the XML to be converted to DDL
--              offsets  - Collection of pointers/lengths into returned CLOB
-- EXCEPTIONS:  Throws an exception if DDL transform was not added.

  FUNCTION convert (
                handle          IN NUMBER,
                document        IN CLOB,
                offsets         OUT NOCOPY multiobjects)
        RETURN CLOB;


-- CONVERT:     Procedure variants to convert an input XML document as
--              specified by user transforms.
-- PARAMETERS:  handle   - Context handle from previous OPENW call.
--              document - XML document containing object metadata of
--                         the type of the OPENW handle.
--              result   - the converted document.
-- EXCEPTIONS:  Throws an exception if no transform was added.

  PROCEDURE convert (
                handle          IN NUMBER,
                document        IN sys.XMLType,
                result          IN OUT NOCOPY CLOB );

  PROCEDURE convert (
                handle          IN NUMBER,
                document        IN CLOB,
                result          IN OUT NOCOPY CLOB );


-- PUT:         Convert an input XML document into creation DDL
--              and submit the resultant DDL to the database. Two forms are
--              provided: One that accepts XML as a CLOB, the other as XMLType.
-- RETURNS:     A BOOLEAN indicating if something went wrong. If TRUE,
--              everything went OK and results doesn't necessarily have to be
--              parsed.
-- PARAMETERS:  handle   - Context handle from previous OPENW call.
--              document - XML document containing object metadata of
--                         the type of the OPENW handle.
--              flags    - Various TBD policy flags
--              results  - A ku$_SubmitResults object passed by reference that
--                         contains detailed results of the operation. Each
--                         object's DDL text, parsed items and associated
--                         error msgs are included.
-- EXCEPTIONS:  Throws an exception if DDL transform was not added or an
--              error occurs during XSL transformation.

  FUNCTION put (
                handle          IN NUMBER,
                document        IN sys.XMLType,
                flags           IN NUMBER,
                results         IN OUT NOCOPY sys.ku$_SubmitResults)
        RETURN BOOLEAN;

  FUNCTION put (
                handle          IN NUMBER,
                document        IN CLOB,
                flags           IN NUMBER,
                results         IN OUT NOCOPY sys.ku$_SubmitResults)
        RETURN BOOLEAN;

   FUNCTION check_match_template (
                pobjno          IN  NUMBER,
                spcnt           IN  NUMBER)
        RETURN  NUMBER;

   FUNCTION check_match_template_par (
                pobjno          IN  NUMBER,
                spcnt           IN  NUMBER)
        RETURN  NUMBER;

   FUNCTION check_match_template_lob (
                pobjno          IN  NUMBER,
                spcnt           IN  NUMBER)
        RETURN  NUMBER;

-----------------------------------------------------------------------
-- GET_EDITION:
--        This function returns the edition of interest for the current MDAPI
--        function. (this is either specified as the 'edition' filter, or
--        the session current edition.
-- RETURNS:
--        VARCHAR2 containing edition name.
-- PARAMETERS:
--        none
-- EXCEPTIONS:  none

  FUNCTION GET_EDITION RETURN VARCHAR2;

-- GET_EDITION_ID:
--        This function returns the edition of interest for the current MDAPI
--        function. (this is either specified as the 'edition' filter, or
--        the session current edition.
-- RETURNS:
--        NUMBER containing edition ID.
-- PARAMETERS:
--        none
-- EXCEPTIONS:  none

  FUNCTION GET_EDITION_ID RETURN NUMBER;

-- GET_VERSION:
--        This function returns the version of interest for the current MDAPI
--        context. Comes from the version parameter in open.
-- RETURNS:
--        NUMBER containing version.
-- PARAMETERS:
--        none
-- EXCEPTIONS:  none

  FUNCTION GET_VERSION
   RETURN VARCHAR2;

-- GET_STAT_COLNAME
--        This function returns a column name for restoring statistics.
-- RETURNS:
--        VARCHAR2 containing the column name
-- PARAMETERS:
--        OWNER_NAME    - schema name that owns the table
--        TABLENAME     - table name where column exists
--        DEFAULT_VAL   - value or null from col$.default$
--        ATTR_COLNAME  - value or null from attrcol$.name
--        NESTED_TABLE  - 1 if nested table, 0 otherwise
-- EXCEPTIONS:  none
--
-- RETURNS:             - COLUMN NAME
  FUNCTION GET_STAT_COLNAME(
          OWNER_NAME   in varchar2,
          TABLENAME    in varchar2,
          DEFAULT_VAL  in long,
          ATTR_COLNAME in varchar2,
          NESTED_TABLE in number)
   RETURN VARCHAR2;

-- GET_STAT_INDNAME
--        This procedure returns an index_owner and index name for restoring
--        statistics.
-- PARAMETERS:
--        TABLE_OWNER  - schema name that owns the table
--        TABLE_NAME   - name of table that index is on
--        COLNAME_LIST - varray of columns that index is on
--        COL_COUNT    - number of columns that index is on
-- RETURNS:
--        IND_OWNER    - owner of index
--        IND_NAME     - name of index
-- EXCEPTIONS:  none
  PROCEDURE GET_STAT_INDNAME(
          TABLE_OWNER  IN  VARCHAR2,
          TABLE_NAME   IN  VARCHAR2,
          COLNAMES     IN  T_VAR_COLL,
          COL_COUNT    IN  NUMBER,
          IND_OWNER    OUT VARCHAR2,
          IND_NAME     OUT VARCHAR2);

-- The following 3 PARSE_ functions are jackets around calls to
-- similar routines in dbms_metadata_util.  If the user has
-- set the PARSE_EXPRESSIONS parameter TRUE, they call the
-- appropriate functions in dbms_metadata_util; otherwise they return NULL.

-- PARSE_CONDITION: Parse a check constraint condition on a table
--   and return it as XML
-- PARAMETERS:
--      schema          - schema
--      tab             - table name
--      length          - length of the constraint
--      row             - rowid of the row in CDEF$
-- RETURNS:     XMLType containing parsed condition as XML
--                 if length is not NULL
--              otherwise NULL

  FUNCTION parse_condition(
                schema          IN  VARCHAR2,
                tab             IN  VARCHAR2,
                length          IN  NUMBER,
                row             IN  ROWID)
        RETURN SYS.XMLTYPE;

-- PARSE_DEFAULT: Parse the default value of a virtual column
--   (which contains an arithmetic expression for a functional index)
--   and return it as XML
-- PARAMETERS:
--      schema          - schema
--      tab             - table name
--      length          - length of the default
--      row             - rowid of the row in COL$
-- RETURNS:     XMLType containing parsed expression as XML
--                 if length is not NULL
--              otherwise NULL

  FUNCTION parse_default(
                schema          IN  VARCHAR2,
                tab             IN  VARCHAR2,
                length          IN  NUMBER,
                row             IN  ROWID)
        RETURN SYS.XMLTYPE;

-- PARSE_QUERY: Parse a query stored in a long column (e.g., view query).
--   and return it as XML
-- PARAMETERS:
--      schema          - schema
--      length          - length of the LONG
--      tab             - table name
--      col             - column name
--      row             - rowid of the row
--      read_only       - non-0 = query has 'with read only'
--      check_option    - non-0 = query has 'with check option'
-- RETURNS:     XMLType containing parsed query as XML
--                 if length is not NULL
--              otherwise NULL

  FUNCTION parse_query(
                schema          IN  VARCHAR2,
                length          IN  NUMBER,
                tab             IN  VARCHAR2,
                col             IN  VARCHAR2,
                row             IN  ROWID,
                read_only       IN  NUMBER DEFAULT 0,
                check_option    IN  NUMBER DEFAULT 0)
        RETURN SYS.XMLTYPE;

-- GET_CHECK_CONSTRAINT_NAME - Return the constraint name given the
--                   condition. (Useful if name is system-generated.)
-- PARAMETERS:
--      object_type     - object type of base object
--      schema          - Schema containing the base object.
--      name            - Name of the base object.
--      condition       - condition (parsed or unparsed)
--      parsed_condition- boolean; TRUE = condition is parsed
-- RETURNS:     Constraint name or NULL if not found

  FUNCTION get_check_constraint_name(
                object_type     IN  VARCHAR2,
                schema          IN  VARCHAR2,
                name            IN  VARCHAR2,
                condition       IN  CLOB,
                parsed_condition IN  BOOLEAN DEFAULT FALSE)
        RETURN VARCHAR2;

-- OPEN_GET_FK_CONSTRAINT_NAME - This and the following 2 apis return
--                   the name of a foreign key constraint given its
--                   definition. (Useful if name is system-generated.)
-- PARAMETERS:
--      object_type     - object type of base object
--      schema          - Schema containing the base object.
--      name            - Name of the base object.
--      ref_schema      - Schema containing the referenced object.
--      ref_name        - Name of the referenced object.
-- RETURNS:     Handle to be used in subsequent calls.

  FUNCTION open_get_fk_constraint_name(
                object_type     IN  VARCHAR2,
                schema          IN  VARCHAR2,
                name            IN  VARCHAR2,
                ref_schema      IN  VARCHAR2,
                ref_name        IN  VARCHAR2)
        RETURN NUMBER;

-- SET_FK_CONSTRAINT_COL_PAIR - After calling OPEN_GET_FK_CONSTRAINT_NAME,
--   the program calls this for each pair of corresponding columns.
--   The order of calls defines the order of columns in the constraint.
-- PARAMETERS:
--      handle          - handle returned by OPEN_GET_FK_CONSTRAINT_NAME
--      src_col         - name of column in base table
--      tgt_col         - name of corresponding column in ref table

  PROCEDURE set_fk_constraint_col_pair(
                handle          IN  NUMBER,
                src_col         IN  VARCHAR2,
                tgt_col         IN  VARCHAR2);


-- GET_FK_CONSTRAINT_NAME
-- PARAMETERS:
--      handle          - handle returned by OPEN_GET_FK_CONSTRAINT_NAME
-- RETURNS:     Constraint name or NULL if not found

  FUNCTION get_fk_constraint_name(
                handle          IN  NUMBER)
        RETURN VARCHAR2;


---------------------------------------------------------------------
-- IS_ATTR_VALID_ON_10 -
--
-- PARAMETERS:
--      obj_num         - base table object #
--      intcol_num      - intcol# from icol$
--
-- This is a wrapper function around dbms_metadata_int.is_attr_valid_on_10.


  FUNCTION is_attr_valid_on_10(obj_num IN NUMBER,
                               intcol_num in NUMBER)
        RETURN NUMBER;


END DBMS_METADATA;
/

