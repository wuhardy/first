create procedure DBMS_FEATURE_TEST_PROC_4
     ( feature_boolean  OUT  NUMBER,
       aux_count        OUT  NUMBER,
       feature_info     OUT  CLOB)
AS
begin

    /* raise an application error to make sure the error is being
     * handled correctly
     */
    raise_application_error(-20020, 'Error for Test Proc 4 ');

end;
/

