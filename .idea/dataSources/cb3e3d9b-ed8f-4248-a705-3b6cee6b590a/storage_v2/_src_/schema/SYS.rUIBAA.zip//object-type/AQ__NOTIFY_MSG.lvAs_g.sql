create TYPE     aq$_notify_msg AS OBJECT (
        opcode INTEGER, qid RAW(16), dest VARCHAR2(128))
/

