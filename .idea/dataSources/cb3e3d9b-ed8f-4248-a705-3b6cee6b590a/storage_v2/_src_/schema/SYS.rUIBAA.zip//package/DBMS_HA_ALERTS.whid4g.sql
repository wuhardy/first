create PACKAGE dbms_ha_alerts AS

  /****************************************************************************
  * NAME
  *   get_XXX - Kernel High availability Notifications get alert attributes
  *
  * DESCRIPTION
  *   These routines are the PL/SQL public interface for getting attributes
  *   from HA alerts.
  *
  * PARAMETER
  *  alert      - an HA alert to decompose
  *
  * RETURNS
  *  the appropriate attribute
  ****************************************************************************/
  FUNCTION get_service       (alert ALERT_TYPE) RETURN VARCHAR2;
  FUNCTION get_instance      (alert ALERT_TYPE) RETURN VARCHAR2;
  FUNCTION get_db_unique_name(alert ALERT_TYPE) RETURN VARCHAR2;
  FUNCTION get_db_domain     (alert ALERT_TYPE) RETURN VARCHAR2;
  FUNCTION get_host          (alert ALERT_TYPE) RETURN VARCHAR2;
  FUNCTION get_incarnation   (alert ALERT_TYPE) RETURN VARCHAR2;
  FUNCTION get_cardinality   (alert ALERT_TYPE) RETURN BINARY_INTEGER;
  FUNCTION get_severity      (alert ALERT_TYPE) RETURN BINARY_INTEGER;
  FUNCTION get_event_time    (alert ALERT_TYPE)RETURN TIMESTAMP WITH TIME ZONE;
  FUNCTION get_reason        (alert ALERT_TYPE) RETURN VARCHAR2;
  FUNCTION get_version       (alert ALERT_TYPE) RETURN VARCHAR2;

END dbms_ha_alerts;
/

