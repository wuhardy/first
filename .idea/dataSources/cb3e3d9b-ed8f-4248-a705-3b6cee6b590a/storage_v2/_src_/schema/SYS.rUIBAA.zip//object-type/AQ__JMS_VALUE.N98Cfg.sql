create type aq$_jms_value
                                       wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
90 a6
/yJjndUcJ8BvvwuYtU4zUcyRkJ4wg5n0dLhcWlbD9HKXYkqWDEc+LlyPwHQrpb+bwDLL7iWP
CWnn+yap4Z1pD0mxyrLvLqTRfEkiR7NboeEU/IruBDa2OS0qdK8YhHHv5o8VIvncyn+whS+x
cE0OtmlfDOvs+6YsjKjN
/

