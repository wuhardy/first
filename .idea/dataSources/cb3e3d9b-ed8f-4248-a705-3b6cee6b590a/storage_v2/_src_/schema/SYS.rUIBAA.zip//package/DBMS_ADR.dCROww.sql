create PACKAGE dbms_adr AS

  --
  -- migrate_schema()
  --   This routine migrates the ADR home to the current version
  --
  -- Input arguments:
  --   none
  --
  PROCEDURE migrate_schema;

  --
  -- downgrade_schema()
  --   This routine downgrades the ADR home by restoring files
  --
  -- Input arguments:
  --   none
  --
  PROCEDURE downgrade_schema;

  --
  -- recover_schema()
  --   This routine tries to bring the ADR home to a consistent state
  --   after a failed migrate or downgrade operation.
  --
  -- Input arguments:
  --   none
  --
  PROCEDURE recover_schema;

  --
  -- cleanout_schema()
  --   This routine recreates the ADR home, without any diagnostic contents
  --
  -- Input arguments:
  --   none
  --
  PROCEDURE cleanout_schema;

END dbms_adr;
/

