create PROCEDURE DBMS_FEATURE_RMAN_BASIC
     ( feature_boolean  OUT  NUMBER,
       aux_count        OUT  NUMBER,
       feature_info     OUT  CLOB)
AS
BEGIN

    /* assume that feature is not used. */
    feature_boolean := 0;
    aux_count := 0;
    feature_info := NULL;

    /* Get the number of backup pieces created with compression whose status is
     * 'available', controlfile autobackups are ignored, because we don't
     * want to consider RMAN in use if they just turned on the
     * controlfile autobackup feature.
     * DEFAULT is a compatible 11.2 algorithm, and backup sets with
     * bscal of 16 or 80 indicate the usage of this algorithm.
     */
    SELECT count(*)
      INTO aux_count
      FROM (SELECT bp.set_stamp, bp.set_count
              FROM x$kccbs bs
              JOIN v$backup_piece bp
                ON bsbss = bp.set_stamp
               AND bsbsc = bp.set_count
              LEFT OUTER JOIN
                  (SELECT set_stamp, set_count
                     FROM v$backup_datafile
                 GROUP BY set_stamp, set_count
                   HAVING max(file#) = 0) bdf
                ON bdf.set_stamp = bp.set_stamp
               AND bdf.set_count = bp.set_count
             WHERE bp.status = 'A'
               AND bp.compressed = 'YES'
               AND bdf.set_count IS NULL
               AND bdf.set_stamp IS NULL
               AND bscal in (16, 80));

    IF aux_count > 0 THEN
       feature_boolean := 1;
    END IF;
END;
/

