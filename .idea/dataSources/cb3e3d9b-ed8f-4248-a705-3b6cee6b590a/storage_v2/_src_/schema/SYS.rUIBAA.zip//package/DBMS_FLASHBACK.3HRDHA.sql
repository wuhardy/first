create package dbms_flashback AUTHID CURRENT_USER as

 ----------------
 -- OVERVIEW
 -- Procedures for enabling and disabling dbms_flashback.
 --
 ---------------------------
 -- PROCEDURES AND FUNCTIONS

procedure enable_at_time(query_time in TIMESTAMP);
procedure enable_at_system_change_number(query_scn in NUMBER);
procedure disable;
function  get_system_change_number return NUMBER;

-- Transaction backout constants
nocascade        constant binary_integer := 1;
nocascade_force  constant binary_integer := 2;
nonconflict_only constant binary_integer := 3;
cascade          constant binary_integer := 4;

-- Transaction backout interfaces
procedure transaction_backout(numtxns number,
                              xids    xid_array,
                              options binary_integer default nocascade,
                              scnhint number         default 0);
procedure transaction_backout(numtxns  number,
                              xids     xid_array,
                              options  binary_integer default nocascade,
                              timehint timestamp);
procedure transaction_backout(numTxns number,
                              names   txname_array,
                              options binary_integer default nocascade,
                              scnhint number         default 0);
procedure transaction_backout(numTxns  number,
                              names    txname_array,
                              options  binary_integer default nocascade,
                              timehint timestamp);

end;
/

