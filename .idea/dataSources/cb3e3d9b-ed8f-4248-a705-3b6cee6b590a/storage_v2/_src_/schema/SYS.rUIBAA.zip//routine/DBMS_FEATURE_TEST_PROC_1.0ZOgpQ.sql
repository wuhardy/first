create procedure DBMS_FEATURE_TEST_PROC_1
     ( feature_boolean  OUT  NUMBER,
       aux_count        OUT  NUMBER,
       feature_info     OUT  CLOB)
AS
begin

    /* doesn't matter what I do here as long as the values get
     * returned correctly
     */
    feature_boolean := 0;
    aux_count := 12;
    feature_info := NULL;

end;
/

