create FUNCTION blastp_align (
  query_sequence        IN CLOB,
  seqdb_cursor             blast_cur.seqdbcur_t,
  subsequence_from      IN INTEGER   DEFAULT 1,
  subsequence_to        IN INTEGER   DEFAULT -1,
  filter_low_complexity IN INTEGER   DEFAULT 0,
  mask_lower_case       IN INTEGER   DEFAULT 0,
  sub_matrix            IN STRING    DEFAULT 'BLOSUM62',
  expect_value          IN NUMBER    DEFAULT 10,
  open_gap_cost         IN INTEGER   DEFAULT 11,
  extend_gap_cost       IN INTEGER   DEFAULT 1,
  word_size             IN INTEGER   DEFAULT 3,
  x_dropoff             IN INTEGER   DEFAULT 15,
  final_x_dropoff       IN INTEGER   DEFAULT 25
)
RETURN dmbaos AUTHID CURRENT_USER
PARALLEL_ENABLE(PARTITION seqdb_cursor BY ANY)
PIPELINED USING dmbapimp;
/

