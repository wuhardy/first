create PACKAGE dbms_auto_task_export AUTHID CURRENT_USER AS

-- Generate PL/SQL for procedural actions
 FUNCTION system_info_exp(prepost IN PLS_INTEGER,
                          connectstring OUT VARCHAR2,
                          version IN VARCHAR2,
                          new_block OUT PLS_INTEGER)
 RETURN VARCHAR2;

-- import callout for 10.x to 11.x upgrade
PROCEDURE POST_UPGRADE_FROM_10G;

-- downgrade from 11g
PROCEDURE DOWNGRADE_FROM_11G;

END dbms_auto_task_export;
/

