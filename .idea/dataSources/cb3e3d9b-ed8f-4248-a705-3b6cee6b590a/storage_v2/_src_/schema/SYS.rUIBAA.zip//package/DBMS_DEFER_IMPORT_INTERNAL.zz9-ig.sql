create PACKAGE dbms_defer_import_internal wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
194 11f
MkyjPzSyiXOoaXwimXJ7pxcGJLkwg43Q2Z7hf3TpTPiUk8VTwNoKtNQtV+s8oJS/NVI2rx+M
tdAgYC/phMoUuHLXgU3UdbZWHwWMVgpcXNkjErSxSZO73FztEyDdRt/dLBAsapFcIf8VFMxm
a1i/dunwWvA3PhthfOkr710/M/MGMT4l9Ck1fwGEKV0C/XCobwzh61AjH1WxRajmkQtO6kx4
+CqjTo3JwUPCI0d/e28CNWvo/4G5oQye27sckSp9NYii68jOiJe0Wn4thaMXAI+T5g==
/

