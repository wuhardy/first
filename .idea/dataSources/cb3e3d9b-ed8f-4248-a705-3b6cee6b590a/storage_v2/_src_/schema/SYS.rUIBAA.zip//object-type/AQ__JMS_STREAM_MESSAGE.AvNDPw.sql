create type aq$_jms_stream_message
                                       wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
85 b2
DlJD/eh23AREqb33WjvCn+YYTlkwg5n0dLhcWlbD9HKXYkqW0T7yLkfwci5i0dxZrlyPwHQr
pb+bwDLL7iWPCWmluDL1UrIJpvvGZ40wlpqPMOPIy2klPmXbKlcZxj2uNa/rljao010E4g6m
FCFfdHR0IffDktr7WGfxDOvs+6bXFWY3
/

