create PACKAGE DBMS_HS_PARALLEL  authid current_user  as
   no_dblink  exception;
   no_remote_table exception;
   no_view  exception;
   pragma exception_init(no_dblink, -24277);
   pragma exception_init(no_remote_table, -24278);
   pragma exception_init(no_view, -24279);
   no_dblink_num number := -24277;
   no_remote_table_num number := -24278;
   no_view_num number := -24279;
  type hs_part_rec is  record (t hs_partition_obj);
  type hs_partion_rec is  record (t hs_part_obj);
  type hs_sample_rec is  record (t hs_sample_obj);
  type hs_part_refcur_t is ref cursor return hs_part_rec;
  type hs_partion_refcur_t is ref cursor return hs_partion_rec;
  type hs_sample_refcur_t is ref cursor return hs_sample_rec;

  procedure LOAD_TABLE(remote_table in varchar2 ,
   database_link in varchar2 ,
   oracle_table in varchar2 := null,  truncate in boolean := true,
   parallel_degree in integer := null,  row_count out number) ;
  procedure CREATE_OR_REPLACE_VIEW(remote_table in varchar2 ,
   database_link in varchar2 ,
   oracle_view  in varchar2 :=  null, parallel_degree in integer := null ) ;
  procedure DROP_VIEW(oracle_view in varchar2);
  procedure CREATE_TABLE_TEMPLATE (remote_table in varchar2, database_link in varchar2,
   oracle_table in varchar2 := null, create_table_template_string out varchar2);

end DBMS_HS_PARALLEL;
/

